import glob
import os
from qe_tools import *
from config_tool import *
from crystal_enum import *
from subprocess import call
from ase.io import iread,write

def setupEosCalcs():
    struct_files = glob.glob('*rlx.cif')
    for fileindex,sfile in enumerate(struct_files):
        temp_atoms = read(sfile)
        prefix = sfile.split('.')[0] # get name of file 
        a = np.linalg.norm(temp_atoms.get_cell()[0]) # relaxed lattice parameter
        compress_expand(temp_atoms, a, prefix = prefix, axes = [0,1,2], stepsize=0.12, nsteps = 4)
        #glob up compressed and expanded files
        eos_files = glob.glob('*eos_*cif')
        for eos_index,eos_file in enumerate(eos_files):
            atoms = read(eos_file) # moved from above
            eos_prefix = eos_file.split('.')[0]
            #setup_calc_for_struct(eos_file)
            #call('mv %s ./run_%s' % (eos_file,eos_prefix),shell = True)
            qei = QEInput(atoms)
            ishex = False
            if 'hex' in prefix:
                ishex = True
            qei.generate_kpoints(density=45,ishex=ishex)
            qei.kpoints_settings(qei.kpoints,qei.kpoints_shft)
            qei.default_settings(spin_polarized=True)
            qei.control['calculation'] = 'scf' # change from default cell relaxation to single scf (energy calculation)
            qei.system['ecutwfc'] = 80.0
            qei.system['ecutrho'] = 320.0
            qei.electrons['conv_thr'] = 1.E-9 # conv_thr scales with # of electrons. must be more stringent for small systems!
            #qei.system['nosym']= '.false.' # turn symmetry back on to speed up! (you just wont print forces)
            dirname = 'eos_%03d' % eos_index
            if not os.path.isdir(dirname):
                os.mkdir(dirname)
            qei.write_input('./%s/%s.in' % (dirname, eos_prefix))
            call('cp %s ./%s' % (sfile,dirname),shell = True)


struct_files = glob.glob('*.cif')
for fileindex,sfile in enumerate(struct_files):
    dirname = 'run_%03d' % fileindex
    os.chdir(dirname)
    print('running setup eos calcs in ',dirname)
    setupEosCalcs()
    os.chdir('../')
