import glob
import os
from crystal_enum import *
from qe_tools import *
from subprocess import call
import time

#get_prim_structs(['Ni'])


struct_files = glob.glob('*.cif')
for fileindex,sfile in enumerate(struct_files):
    atoms = read(sfile)
    prefix = sfile.split('.')[0]
    qei = QEInput(atoms)
    ishex = False
    if 'hex' in prefix:
        ishex = True
    qei.generate_kpoints(density=45,ishex=ishex)
    qei.kpoints_settings(qei.kpoints,qei.kpoints_shft)
    qei.default_settings(spin_polarized=True)
    qei.electrons['scf_must_converge']= '.false.'
    qei.electrons['mixing_mode']='local-TF'
    qei.electrons['mixing_beta']=0.3
    #qei.system['nosym']= '.false.' # turn symmetry back on to speed up! (you just wont print forces)
    dirname = 'run_%03d' % fileindex
    if not os.path.isdir(dirname):
        os.mkdir(dirname)
    #time.sleep(2)
    qei.write_input('./%s/%s.in' % (dirname, prefix),1.25) # added a scale factor of 1.5
    
    time.sleep(0.5)
    call('cp %s ./%s' % (sfile,dirname),shell = True)
