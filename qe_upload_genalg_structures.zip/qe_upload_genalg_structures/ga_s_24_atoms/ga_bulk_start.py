from ase import Atoms
from ase.data import atomic_numbers
from ase.ga.utilities import closest_distances_generator, CellBounds
from ase.ga.startgenerator import StartGenerator
from ase.ga.data import PrepareDB
from ase.io import read,write

# Number of random initial structures to generate
N = 20

# ! originally 20

# Target cell volume for the initial structures, in angstrom^3
# volume of each atom (Ni)
Ni_vol = 12.688954970599907
nat = 24 # initially set to 24
volume = Ni_vol*nat

# Specify the 'building blocks' from which the initial structures
# will be constructed. Here we take single Ni atoms as building
# blocks, nat in total.
blocks = [('Ni', nat)]
# We may also write:
blocks = ['Ni'] * nat

# Generate a dictionary with the closest allowed interatomic distances
Z = atomic_numbers['Ni']
blmin = closest_distances_generator(atom_numbers=[Z],
                                    ratio_of_covalent_radii=0.7)
# ! originally 0.5

# Specify reasonable bounds on the minimal and maximal
# cell vector lengths (in angstrom) and angles (in degrees)
cellbounds = CellBounds(bounds={'phi': [50, 120], 'chi': [50, 120],
                                'psi': [50, 120], 'a': [3, 20],
                                'b': [3, 20], 'c': [3, 20]})

# Choose an (optional) 'cell splitting' scheme which basically
# controls the level of translational symmetry (within the unit
# cell) of the randomly generated structures. Here a 1:1 ratio
# of splitting factors 2 and 1 is used:
splits = {(2,): 1, (1,): 1}
# There will hence be a 50% probability that a candidate
# is constructed by repeating an randomly generated Ni12
# structure along a randomly chosen axis. In the other 50%
# of cases, no cell cell splitting will be applied.

# The 'slab' object in the GA serves as a template
# in the creation of new structures, which inherit
# the slab's atomic positions (if any), cell vectors
# (if specified), and periodic boundary conditions.
# Here only the last property is relevant:
slab = Atoms('', pbc=True)

# Initialize the random structure generator
sg = StartGenerator(slab, blocks, blmin, box_volume=volume,
                    number_of_variable_cell_vectors=3,
                    cellbounds=cellbounds, splits=splits)

# Create the database
da = PrepareDB(db_file_name='gadb.db',
               stoichiometry=[Z] * nat)

# Generate N random structures
# and add them to the database
for i in range(N):
    a = sg.get_new_candidate()
    da.add_unrelaxed_candidate(a)
    write('atoms_%03d.cif' % i, a)
