import glob
import os
import time
from qe_tools import *
from config_tool import *
from crystal_enum import *
from subprocess import call
from ase.io import iread,write

def eosSlurmHelper(qeinput, job_name, outfile, node_num=23):
    slurm_str = """#!/bin/bash
#SBATCH --nodes=1
#SBATCH -w, --nodelist=node[%d]
#SBATCH --overcommit
#SBATCH --ntasks-per-node=24
#SBATCH --time=24:00:00
#SBATCH --job-name=%s
#SBATCH --output=%s
###SBATCH -p week-long-cpu
#SBATCH --partition=day-long-cpu

source ~/.bashrc

module load intel/2018.2.199
module load openmpi/intel/2018.2.199/4.0.0

export PATH=$PATH:/mnt/nfs/wenwu/kyrel/qeInstall/qe-7.2/bin
export PYTHONPATH=$PYTHONPATH:/mnt/nfs/wenwu/kyrel/automation_tutorial-main/tools/
export TUTORIAL_PATH=/mnt/nfs/wenwu/kyrel/automation_tutorial-main
export ESPRESSO_PSEUDO=$TUTORIAL_PATH/qe_pseudos

echo "$PWD"

mpirun pw.x < %s""" % (node_num, job_name, outfile, qeinput)
#                        int       str      str      str
    return slurm_str

def eosSlurm():
    struct_files = glob.glob('*eos_*.cif')
    for fileindex,sfile in enumerate(struct_files):
        dirname = 'eos_%03d' % fileindex
        prefix = sfile.split('.')[0]
        os.chdir(dirname)
        #print(dirname)
        #print(prefix)
        os.chdir('../')
        myoutfile = '%s.out' % prefix  # output from quantum espresso
        myinfile = '%s.in' % prefix  # input for quantum espresso
        #ex_json_prefix = '%s_rlx' % prefix # prefix for json file

        slurm_file = './%s/submit_%03d.slurm' % (dirname, fileindex)
        qeinput = '%s.in' % prefix
        job_name = 'sim_%03d' % fileindex
        outfile = '%s.out' % prefix 
        slurm_str = eosSlurmHelper(qeinput, job_name, outfile, node_num=23)
        print(dirname, ' ', prefix)
        with open(slurm_file, 'w') as swrite_file:
            swrite_file.write(slurm_str)

struct_files = glob.glob('*.cif')
for fileindex,sfile in enumerate(struct_files):
    dirname = 'run_%03d' % fileindex
    os.chdir(dirname)
    print('running setup eos slurm in ',dirname)
    eosSlurm()
    os.chdir('../')
