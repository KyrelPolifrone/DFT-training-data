import glob
import os
import time
from qe_tools import *
from config_tool import *
from crystal_enum import *
from subprocess import call
from ase.io import iread,write


def eosSlurm():
    struct_files = glob.glob('*eos_*.cif')
    for fileindex,sfile in enumerate(struct_files):
        dirname = 'eos_%03d' % fileindex
        prefix = sfile.split('.')[0]
        #print(dirname)
        #print(prefix)
        
        slurm_file = 'submit_%03d.slurm' % fileindex
        os.chdir(dirname)
        shell_line = 'sbatch %s' % slurm_file
        print (shell_line)
        call(shell_line, shell=True) # comment this out to do a dry run
        os.chdir('../')
        
        myoutfile = '%s.out' % prefix  # output from quantum espresso
        myinfile = '%s.in' % prefix  # input for quantum espresso
        #ex_json_prefix = '%s_rlx' % prefix # prefix for json file


struct_files = glob.glob('*.cif')
for fileindex,sfile in enumerate(struct_files):
    dirname = 'run_%03d' % fileindex
    os.chdir(dirname)
    print('running submit eos slurm in ',dirname)
    eosSlurm()
    os.chdir('../')
