from config_tool import *
rytoev = 13.6057039763
autoAA = 0.529177249
from ase.io import iread,write
#Ry/au * (au/AA) * (eV/Ry) = (eV/AA)
#Ry/au^2  * (au/AA) *(au/AA) * (eV/Ry) = eV/AA
ryperau_to_evperAA = rytoev*autoAA
rystress_to_evstress = ryperau_to_evperAA*autoAA
#def slines_to_data(lines):
#    forces = []
#    stresses = []
#    for line in lines:
#        l = line.split()

def convert_stress_tensor_to_force(stress_tensor):
    surface_areas = np.array([
        np.linalg.norm(np.cross(a, b))
        for a, b in [
            (stress_tensor[:, 1], stress_tensor[:, 2]),
            (stress_tensor[:, 2], stress_tensor[:, 0]),
            (stress_tensor[:, 0], stress_tensor[:, 1])
        ]
    ])

    # Calculate the force per atom NOTE for single atom unit cell only!
    force_per_atom = np.sum(stress_tensor * surface_areas[:, None])
    return force_per_atom

def flines_to_forces(lines):
    forces = []
    for line in lines:
        l = line.split()
        f = [float(l[-3])*ryperau_to_evperAA,float(l[-2])*ryperau_to_evperAA,float(l[-1])*ryperau_to_evperAA]
        forces.append(f)
    return forces

def slines_to_stresses(lines):
    stresses = []
    for line in lines:
        l = line.split()
        s = [float(l[0])*rystress_to_evstress,float(l[1])*rystress_to_evstress,float(l[2])*rystress_to_evstress]
        stresses.append(s)
    return stresses

def parse_stresses(outfile,infile,trajectory_index=None):
    try:
        base_atoms = read(outfile)
    except TypeError:
        base_atoms = read(infile,format='espresso-in')
    #NOTE this assumes that no extra force contributions are made (e.g through external packages like environ)
    with open(outfile,'r') as readin:
        lines = readin.readlines()
        #flines = [line for line in lines if 'force' in line and 'cont' not in line and 'conv' not in line and 'corr' not in line and 'CPU' not in line and 'crit' not in line and 'Dyn' not in line]
        flineinds = [lineid for lineid,line in enumerate(lines) if 'total   stress' in line]
        fsteps = {flineind:lines[flineind +1: flineind+1+3] for flineind in flineinds }
        sperstep = {flineind:slines_to_stresses(fsteps[flineind]) for flineind in flineinds}
        print(sperstep)
    if trajectory_index != None:
        stresses = sperstep[flineinds[trajectory_index]]
        return stresses
    else:
        return list(sperstep.values())

def parse_forces(outfile,infile,trajectory_index=None):
    try:
        base_atoms = read(outfile)
    except TypeError:
        base_atoms = read(infile,format='espresso-in')
    #NOTE this assumes that no extra force contributions are made (e.g through external packages like environ)
    with open(outfile,'r') as readin:
        lines = readin.readlines()
        #flines = [line for line in lines if 'force' in line and 'cont' not in line and 'conv' not in line and 'corr' not in line and 'CPU' not in line and 'crit' not in line and 'Dyn' not in line]
        flineinds = [lineid for lineid,line in enumerate(lines) if 'Forces acting on atoms' in line]
        fsteps = {flineind:lines[flineind +2: flineind+2 +len(base_atoms)] for flineind in flineinds }
        fperstep = {flineind:flines_to_forces(fsteps[flineind]) for flineind in flineinds}
        print(fperstep)

    if trajectory_index != None:
        forces = fperstep[flineinds[trajectory_index]]
        return forces
    else:
        return list(fperstep.values())

def parse_energies(outfile,trajectory_index=None):
    with open(outfile,'r') as readin:
        lines = readin.readlines()
        enlines = [line for line in lines if '!' in line]
        ens = [float(enline.split()[-2])*rytoev for enline in enlines]
    if trajectory_index != None:
        return ens[trajectory_index]
    else:
        return ens

myoutfile = 'Ni_cubic_fcc_atoms.out' # output from quantum espresso
myinfile = 'Ni_cubic_fcc_atoms.in' # input for quantum espresso
ex_json_prefix = 'Ni_cubic_fcc_atoms_rlx' # prefix for json file 
forces_traj = parse_forces(myoutfile,myinfile)
stresses_traj = parse_forces(myoutfile,myinfile)
energy_traj = parse_energies(myoutfile)

#print ('NOTE', energy_traj[0],' is not referenced!, consider subtracting a reference state energy from each value (e.g. the energy of an isolated atom)')
#reffed_energy = energy[0] - (len(atoms) * eref) # for example if eref is the energy of an isolated atom

try:
    atoms_traj = [ati for ati in iread(myoutfile,format='espresso-out') ]
    print (len(atoms_traj))
except TypeError:
    atoms = read(myinfile,format='espresso-in')

for traj_ind, energy in enumerate(energy_traj):
    #forces = forces_traj[traj_ind]
    stresses = stresses_traj[traj_ind]
    atoms = atoms_traj[traj_ind] 
    cell = atoms.get_cell() #[(1,0,0),(0,1,0)...]
    #volume = np.dot(cell[0], np.cross(cell[1],cell[2]))

    if len(atoms) == 1:
       forces = convert_stress_tensor_to_force(stresses)
    else:
       forces = forces_traj[traj_ind]
    datadct = {'Forces':forces,
    print ('NOTE', forces, ' if all of your forces are zero, you may need to turn off symmetry! (set nosym = .true. in your quantum espresso input)')
    'Energy':energy,
    'Stress':stresses,
    }
    
    fsats = fsnap_atoms()
    fsats.set_ASE(atoms,**datadct)
    fsats.write_JSON(ex_json_prefix + '_%d' % traj_ind,write_header=False)
    if traj_ind == len(energy_traj) -1:
        write('%s.cif' % ex_json_prefix,atoms)
